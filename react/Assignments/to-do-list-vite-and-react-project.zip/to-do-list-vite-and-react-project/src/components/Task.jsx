import React, { useState } from 'react'
import "./Task.css"
// import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'


const Task = ({taskName , id ,deleteTaskHandler }) => {
    const [taskStatus, setTaskStatus] = useState(false)
    const [showBtn,setShowBtn] = useState(true)
    const handleTaskStatus = () => {
        setTaskStatus(true)
        setShowBtn(false)
    }
  
  return (
    <>
     <div>
        <div className={taskStatus ? "completed-task task-container" : "incomplete-task task-container"} > 
        <h5>{id +1}.</h5>
        <h3>{taskName}</h3>
        <div className='button-container'>
        {showBtn && <button onClick={handleTaskStatus}>mark as complete<i class="fa-regular fa-check"></i></button>}
        <button onClick={deleteTaskHandler}>Delete</button>
        </div>
        </div>
    </div>

    </>
  )
}

export default Task
