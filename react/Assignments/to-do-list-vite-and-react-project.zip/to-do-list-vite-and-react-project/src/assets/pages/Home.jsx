import React from 'react'
import TaskList from '../../components/TaskList'
import AddTask from '../../components/AddTask'

const Home = () => {
  return (
    <div>
      
      {/* <AddTask inputTaskName={inputTaskName} setTaskList={setTaskList} setInputTaskName={setInputTaskName}/> */}
      <TaskList/> 
    </div>
  )
}

export default Home
