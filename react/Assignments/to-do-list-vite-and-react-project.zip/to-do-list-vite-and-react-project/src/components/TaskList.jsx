import React, { useEffect, useState } from "react";
import Task from "./Task";

const TaskList = () => {
  const [inputTaskName, setInputTaskName] = useState("");
  const [taskList, setTaskList] = useState([]);
  const handleAddTask = (inputTaskName) => {
    if (inputTaskName === "") {
      // console.log("empty task name")
      return "invalid task name";
    } else {
      const newTaskList = [...taskList, inputTaskName];
      setTaskList(newTaskList);
      localStorage.setItem("tasklist", [...taskList, inputTaskName]);
      setInputTaskName("");
      console.log("input name khali hojana chahaye");
    }
  };

  const handleRemoveTask = (TaskIdToBeDeleted) => {
    const newFilteredTaskArr = taskList.filter((taskEntry, index) => {
      return TaskIdToBeDeleted !== index;
    });
    setTaskList(newFilteredTaskArr);
    console.log("newFilteredTaskArr after deletion: ", newFilteredTaskArr);
  };

  // localStorage.setItem("updatedTaskList",taskList)

  useEffect(()=>{
      localStorage.getItem("tasklist")
      console.log("useEffect chala: ",taskList)
  },[taskList])

  return (
    <div className="task-list-container">
      <input
        type="text"
        placeholder="Task name"
        onChange={(e) => setInputTaskName(e.target.value)}
      />
      <button onClick={() => handleAddTask(inputTaskName)}>Add</button>
      {taskList.length > 0 &&
        taskList.map((taskEntry, index) => (
          <Task
            taskName={taskEntry}
            id={index}
            deleteTaskHandler={() => {
              handleRemoveTask(index);
            }}
          />
        ))}
    </div>
  );
};

export default TaskList;
