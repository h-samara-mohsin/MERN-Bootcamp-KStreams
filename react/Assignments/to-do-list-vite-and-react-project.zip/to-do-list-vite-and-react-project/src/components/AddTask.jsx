import React from 'react'

const AddTask = ({inputTaskName, setTaskList,setInputTaskName}) => {

  const handleAddTask = (inputTaskName) => {
    if (inputTaskName === "" ) {
        // console.log("empty task name")
        return "invalid task name" ;
    } 
    else {
        const newTaskList = [...taskList,inputTaskName]
        setTaskList(newTaskList)
        setInputTaskName("cleared");
    }
}
  return (
    <div>
        <input type="text" placeholder = "Task name" onChange={(e) => setInputTaskName(e.target.value) } />
        <button onClick={() => handleAddTask(inputTaskName)}>Add</button>
    </div>
  )
}

export default AddTask
